import os
import sys

# Pre-initialize cryptography on Windows to ensure correct OpenSSL DLL resolution
try:
    import cryptography
    import cryptography.hazmat.primitives.ciphers
except ImportError:
    pass

# Ensure repository root is on sys.path for test execution
repo_root = os.path.abspath(os.path.join(os.path.dirname(__file__)))
if repo_root not in sys.path:
    sys.path.insert(0, repo_root)

