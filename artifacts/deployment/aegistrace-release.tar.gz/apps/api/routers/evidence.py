from typing import Any, Dict, List
from fastapi import APIRouter, Depends, status

from apps.api.orchestrator import default_orchestrator
from apps.api.security import (
    SecurityPrincipal,
    get_current_actor,
    require_recipient_access,
    require_role,
    validate_id_format,
    verify_tenant_boundary,
)
from core.ledger.ledger import EvidenceEvent

router = APIRouter(prefix="/evidence", tags=["Evidence & Audit"])

@router.get("/{release_id}", response_model=List[EvidenceEvent])
def get_release_evidence(
    release_id: str,
    actor: SecurityPrincipal = Depends(require_role(["investigator", "administrator", "viewer", "authority", "auditor", "system"]))
):
    """
    Retrieve all immutable, cryptographically signed decryption provenance events
    recorded in the tamper-evident ledger for a given release.
    Enforces tenant isolation.
    """
    validate_id_format(release_id, "release_id")
    rel = default_orchestrator.get_release(release_id)
    verify_tenant_boundary(getattr(rel, "tenant_id", "default_tenant"), actor, "release", release_id)

    return default_orchestrator.get_release_evidence(release_id)

@router.post("/decryption-events", status_code=status.HTTP_201_CREATED)
def submit_decryption_event(
    event: EvidenceEvent,
    actor: SecurityPrincipal = Depends(get_current_actor)
):
    """
    Decentralized Decryption Event Ingestion:
    Submits a client-signed EvidenceEvent. The server cryptographically verifies the
    ML-DSA-65 post-quantum signature against the recipient's enrolled public identity
    before appending the event to the tamper-evident ledger.
    Enforces anti-replay, IDOR, and tenant boundaries.
    """
    validate_id_format(event.recipient_id, "recipient_id")
    validate_id_format(event.release_id, "release_id")
    validate_id_format(event.event_id, "event_id")
    require_recipient_access(event.recipient_id, actor)

    rel = default_orchestrator.get_release(event.release_id)
    verify_tenant_boundary(getattr(rel, "tenant_id", "default_tenant"), actor, "release", event.release_id)

    event_hash = default_orchestrator.submit_decryption_event(event)
    return {
        "status": "SUCCESS",
        "event_id": event.event_id,
        "event_hash": event_hash,
        "release_id": event.release_id,
        "recipient_id": event.recipient_id
    }
